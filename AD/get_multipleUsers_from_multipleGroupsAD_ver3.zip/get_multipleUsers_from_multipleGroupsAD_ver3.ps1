﻿<#
.SYNOPSIS 
    Gets the List of AD Group Members from the Associated AD Groups of Multiple Servers 

.DESCRIPTION
    AD Powershell Module is required to run the Script
    Excel is Required to Run this Script
    Input File should have ServerNames without .ca.com
    Input Should be placed in the following path C:\Temp\servers.txt

.NOTES
    AUTHOR: SALMO07
    LASTEDIT: May 22, 2015
    Developed on Powershell Version 4

#>


If(-not(Get-Module -Name ActiveDirectory))
{
    Import-Module -Name ActiveDirectory
}
  
 
 If(-not(Get-Module -Name ActiveDirectory)){
    
    write-host "You Need AD Module to Run this Script"
    
 }else{   
    
$Excel = New-Object -ComObject Excel.Application
$Excel.visible = $True
$Excel = $Excel.Workbooks.Add()
$Sheet = $Excel.Worksheets.Item(1)

$sheet.Name = 'AD_Group_users'

$row = 1
$Sheet.Cells.Item($row,1)  ="Server Name"
$Sheet.Cells.Item($row,2)  ="Group Name"
$Sheet.Cells.Item($row,3)  ="Users List"

$row++

$serverList= get-content C:\Temp\servers.txt
 
    foreach($server in $serverList){

    $col=1
    $server=$server.Trim()
    
    try{
        $group="$($server) Admin Global Group - ca.com"
	
         $memberList=Get-ADGroupMember "$($group)" -Recursive|select name
    

        if($memberList -ne $null){
	    
	        $Sheet.Cells.Item($row,$col) = $server
	        $col++
            $Sheet.Cells.Item($row,$col) = $group
            $col++
            $memberList=$memberList.name            
            $list=@()
            
            foreach($member in $memberList){
      
                $list="$($list)$($member);"
            }

            $Sheet.Cells.Item($row,$col) = $list
            $col++
        }
        else{
            $Sheet.Cells.Item($row,$col) = $server
	        $col++
            $Sheet.Cells.Item($row,$col) = $group
            $col++
            $Sheet.Cells.Item($row,$col) = "Empty"
         }

    $row++

    }
    catch{
            $Sheet.Cells.Item($row,$col) = $server
	        $col++
            $Sheet.Cells.Item($row,$col) = $group
            $col++
            $Sheet.Cells.Item($row,$col) = "No AD Group"
            $row++
    }
     
    }  
}

